/******/ (() => { // webpackBootstrap
  var __webpack_exports__ = {};
  /*!**************************************!*\
    !*** ./src/background/background.js ***!
    \**************************************/
  //NOTIFICATION ON TOGGLE
  const sendNotification = (message) => {
    const logo = chrome.runtime.getURL("./Green 128.png");

    chrome.notifications.create(
      "name-for-notification",
      {
        type: "basic",
        iconUrl: logo,
        title: "Enable Copy and Paste",
        message: `${message} Extension`,
      },

      function () { }
    );
  };

  //ENABLE & DISABLE ON CLICK
  const ScriptAction = (message) => {
    if (message === "enable_function") {
      sendNotification("Enabled");
    } else {
      sendNotification("Disabled");
    }

    //MSG TO CONTENT SCRIPT
    chrome.tabs.query({ currentWindow: true }, function (tabs) {
      for (let index = 0; index < tabs.length; index++) {
        chrome.tabs.sendMessage(
          tabs[index].id,
          { action: `${message}` },
          function (response) { }
        );
      }
    });
  };

  //ACTIVE ICON - GREEN
  const ActiveButton = (PageId) => {
    chrome.action.setIcon({
      path: {
        16: "green icon 16.png",
        48: "Green 64.png",
        128: "Green 128.png",
      },
      tabId: PageId,
    });
  };

  //NOT ACTIVE ICON - RED
  const notActiveButton = (PageId) => {
    chrome.action.setIcon({
      path: {
        16: "icon 16.png",
        48: "icon 64.png",
        128: "icon 128.png",
      },
      tabId: PageId,
    });
  };

  //BUTTON STATUS TOGGLE ON PAGES 
  ButtonToggle = (action, PageId) => {
    if (action) {
      ActiveButton(PageId);
    } else {
      notActiveButton(PageId);
    }
  }

  //LISTENER ON TAB TOGGLE
  chrome.tabs.onUpdated.addListener(function (tab) {
    let PageId = tab.id;

    //FROM LOCAL STORAGE - ICON
    chrome.storage.local.get(["inAction", "isActive"]).then((result) => {
      let action = result.inAction;

      ButtonToggle(action, PageId);

    });
  });

  //LISTENER ON TAB TOGGLE
  chrome.tabs.onActivated.addListener(function (tab) {
    let PageId = tab.tabId;

    //FROM LOCAL STORAGE - ICON
    chrome.storage.local.get(["inAction", "isActive"]).then((result) => {
      let action = result.inAction;

      ButtonToggle(action, PageId);

    });
  });

  //LISTENER ON BROSWER-ACTION CLICK
  chrome.action.onClicked.addListener(function (tab) {
    const PageId = tab.id;

    //FROM LOCAL STORAGE
    chrome.storage.local.get(["isActive"]).then((result) => {
      let state = result.isActive;

      if (state) {
        notActiveButton(PageId);

        ScriptAction("disable_function");

        //MULTI PAGE
        chrome.storage.local.set({ inAction: false }).then(() => { });

        //BROWSER ACTION - ACTIVE
        chrome.storage.local.set({ isActive: false }).then(() => { });
      } else {
        ActiveButton(PageId);

        //MULTI PAGE
        chrome.storage.local.set({ inAction: true }).then(() => { });

        //BROWSER ACTION - NOT ACTIVE
        chrome.storage.local.set({ isActive: true }).then(() => { });

        ScriptAction("enable_function");
      }
    });
  });



  //ON INSTALL TRIGGERER
  chrome.runtime.onInstalled.addListener(function (details) {

    if (details.reason == "install") {


      //DEFAULT SETTING
      chrome.storage.local.set({ isActive: true, inAction: true }).then(() => { });

      // INJECTING CONTENT SCRIPT TO PREVIOUSLY OPENED TABS
      chrome.tabs.query({ currentWindow: true }, function gotTabs(tabs) {
        for (let index = 0; index < tabs.length; index++) {
          let content_scripts = chrome.runtime.getManifest().content_scripts[0];

          if (
            //IGNORED URLS
            tabs[index].url.includes("google")
          ) {
            continue;
          } else {
            chrome.scripting.executeScript(
              {
                target: { tabId: tabs[index].id },

                files: [...content_scripts.js],
              },

              () => (result) => {
                const lastErr = chrome.runtime.lastError;
                console.log(lastErr);
                if (lastErr) {
                }
              }
            );
          }
        }
      });

      chrome.tabs.create({ url: "https://bit.ly/encopyin" }, function () { });
    }

    if (chrome.runtime.setUninstallURL) {
      chrome.runtime.setUninstallURL("https://bit.ly/encunin");
    }
  });

  //GOOGLE CLOUD MESSAGING 
  chrome.gcm.onMessage.addListener(function (message) {
    sendNotification(message);
  });
  /******/
})()
  ;
//# sourceMappingURL=background.js.map
/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!********************************************!*\
  !*** ./src/contentScript/contentScript.js ***!
  \********************************************/
//GLOBAL VARIABLE DECLARED
let style;

//  PAGE REFRESHED
chrome.storage.local.get(["isActive"]).then((result) => {
  let state = result.isActive;
  if (state) {
    addFunction();
  } else {
    removeFunction();
  }
});

//MAIN FUNCTION
const enableUserinteraction = (e) => {
  e.stopImmediatePropagation();
  return true;
};

//ENABLE INTERACTION
const addFunction = () => {
  
  //DEFAULT KEY VALUES
  let keys = {
    a: false,
    c: false,
    v: false,
  };

  //  "Features Working Mode - ON"

  document.addEventListener("contextmenu", enableUserinteraction, true);
  document.addEventListener("copy", enableUserinteraction, true);
  document.addEventListener("paste", enableUserinteraction, true);

  document.addEventListener("keydown",function (event) {

      if (event.key === "Control") keys.a = true;
      if (event.key === "c") keys.c = true;
      if (event.key === "v") keys.v = true;

      if ((keys.a && keys.c) || (keys.a && keys.v)) {
        event.stopImmediatePropagation();

        keys.a = false;
        keys.v = false;
        keys.c = false;
      }
      return true;

    },true);

  setTimeout(() => {
    //ENABLING COPY FROM WEBSITE
    document.querySelectorAll("*").forEach((item) => {
      style = getComputedStyle(item).userSelect;
      if (style === "none") {
        style = "text";
      }
    });

    document.querySelectorAll("*").forEach((item) => {
      item.style.userSelect = style;
    });
  }, 2000);
};

//DISABLE INTERACTION
const removeFunction = () => {
  //  "Features Working Mode - OFF"

  document.removeEventListener("contextmenu", enableUserinteraction, true);
  document.removeEventListener("copy", enableUserinteraction, true);
  document.removeEventListener("paste", enableUserinteraction, true);
  document.removeEventListener("keydown", enableUserinteraction, true);

  setTimeout(() => {
    //DISABLING COPY ON WEBSITE
    document.querySelectorAll("*").forEach((item) => {
      if (item.style.userSelect === "text") {
        item.style.userSelect = "none";
      }
    });
  }, 1000);
};

//ADDING LISTENER FROM BG
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  //FROM CONTENT SCRIPT
  if (request.action === "enable_function") {
    addFunction();
  } else if (request.action === "disable_function") {
    removeFunction();
  }
});

/******/ })()
;
//# sourceMappingURL=contentScript.js.map
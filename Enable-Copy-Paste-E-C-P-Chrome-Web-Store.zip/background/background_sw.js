/*
Copyright (c) 2021, KodeMuse.dev. All rights reserved.

Use and re-distribution is allowed as per license.txt file.

For any query or improvements related to the code contact original 
authors at contact@kodemuse.dev.
*/

console.log('service worker');

var ecpDocUrl = "https://www.kodemuse.dev/enable-copy-paste/";
chrome.runtime.setUninstallURL(ecpDocUrl);

chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === "install") {
    // Set your desired URL
    chrome.tabs.create({ url: ecpDocUrl.toString() });
  }
});

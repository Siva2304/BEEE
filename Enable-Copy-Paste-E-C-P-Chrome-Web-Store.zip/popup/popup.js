/*
Copyright (c) 2021, KodeMuse.dev. All rights reserved.

Use and re-distribution is allowed as per license.txt file.

For any query or improvements related to the code contact original 
authors at contact@kodemuse.dev.
*/

var manifest; // extension manifest, initialized when window loads

var classNameDisableNavBtn = "disabled-nav-btn";

var elIdToolTitle;
var elToolTitle = "tool-title";

var elIdToolVersion = "tool-version";
var elToolVersion;

var elIdEnableCheckbox = "enable-checkbox";
var elEnableCheckbox;

var elIdDarkModeCheckbox = "dark-mode-checkbox";
var elDarkModeCheckbox;

var elIdAggressiveModeCheckbox = "aggressive-mode-checkbox";
var elAggressiveModeCheckbox;

var localStorageNameDarkModeStatus = "dark_mode_status";

var elIdDarkModeStylesheet = "dark-mode-stylesheet";
var elDarkModeStylesheet;

var crStorageNameEnableProduct = "enable_product";
var crStorageNameAggressiveMode = "aggressive_mode";

function logAllCrStorage() {
  chrome.storage.local.get(
  [
    crStorageNameEnableProduct,
    crStorageNameAggressiveMode,
  ],
  function(data){
    console.log("data is", data);
  });
}

function loaded() {
  console.log("loaded called");

  //
  // load data
  //
  manifest = chrome.runtime.getManifest(); // load manifest when app loads

  //
  // init element
  //
  elToolTitle = document.getElementById(elToolTitle); // init tool element
  elToolVersion = document.getElementById(elIdToolVersion);
  elToolVersion.innerText = " V " + manifest.version;
  elEnableCheckbox = document.getElementById(elIdEnableCheckbox);
  elDarkModeCheckbox = document.getElementById(elIdDarkModeCheckbox);
  elAggressiveModeCheckbox = document.getElementById(elIdAggressiveModeCheckbox);
  elDarkModeStylesheet = document.getElementById(elIdDarkModeStylesheet);

  // apply dark mode if set to enable
  if(localStorage[localStorageNameDarkModeStatus]) {
    if(localStorage[localStorageNameDarkModeStatus] == "enable"){
      elDarkModeStylesheet.href="popup_dark.css";
      elDarkModeCheckbox.checked = true;
    }
  }

  // apply data based on previous storage state
  chrome.storage.local.get(
  [
    crStorageNameEnableProduct,
  ],
  function(data){
    console.log("data is", data);
    if(data[crStorageNameEnableProduct] === true) {
      // product is enabled
      elEnableCheckbox.checked = true;
    }else{
      // product is disabled
      elEnableCheckbox.false = true;
      elAggressiveModeCheckbox.disabled = "disabled";
    }
  });

  chrome.storage.local.get(
  [
    crStorageNameAggressiveMode,
  ],
  function(data){
    console.log("data is", data);
    if(data[crStorageNameAggressiveMode] === true) {
      // aggressive mode is enabled
      elAggressiveModeCheckbox.checked = true;
    }else{
      // aggressive mode is disabled
      elAggressiveModeCheckbox.checked = false;
    }
  });

  //
  // event listener
  //
  elEnableCheckbox.addEventListener('change', function(event) {
    if (event.currentTarget.checked) {
      console.log("enable checkbox checked");
      
      // set extension as enabled
      var newStorageData = {};
      newStorageData[crStorageNameEnableProduct] = true;
      
      // set as enabled
      chrome.storage.local.set(newStorageData, function(newData){
        console.log("newData is", newData);
      });

      // enable aggresive mode checkbox
      elAggressiveModeCheckbox.disabled = "";

    } else {
      console.log("enable checkbox not checked");

      // set extension as disabled
      var newStorageData = {};
      newStorageData[crStorageNameEnableProduct] = false;
      
      // set as enabled
      chrome.storage.local.set(newStorageData, function(newData){
        console.log("newData is", newData);
      });

      // mark aggresive mode off if not off
      if(elAggressiveModeCheckbox.checked != false) {
        elAggressiveModeCheckbox.checked = false;
      }
      
      // disable aggressive mode checkbox
      elAggressiveModeCheckbox.disabled = "disabled";

      // store aggressive mode checkbox disabled data to storage
      // set extension as enabled
      var newStorageDataAggressiveMode = {};
      newStorageDataAggressiveMode[crStorageNameAggressiveMode] = false;
      
      // set as enabled
      chrome.storage.local.set(newStorageDataAggressiveMode,
      function(newData){
        console.log("newData is", newData);
      });

    }
  });

  elAggressiveModeCheckbox.addEventListener('change', function(event) {
    if (event.currentTarget.checked) {
      console.log("aggressive mode checkbox checked");

      // mark enable checkbox on if not on
      if(elEnableCheckbox.checked == false) {
        elEnableCheckbox.checked = true;
      }
      
      // set extension as enabled
      var newStorageData = {};
      newStorageData[crStorageNameAggressiveMode] = true;
      
      // set as enabled
      chrome.storage.local.set(newStorageData, function(newData){
        console.log("newData is", newData);
      });

    } else {
      console.log("aggressive mode checkbox checked");

      // set extension as enabled
      var newStorageData = {};
      newStorageData[crStorageNameAggressiveMode] = false;
      
      // set as enabled
      chrome.storage.local.set(newStorageData, function(newData){
        console.log("newData is", newData);
      });
    }
  });
  
  elDarkModeCheckbox.addEventListener('change', function(event) {
    if (event.currentTarget.checked) {
      // enable dark mode
      console.log("dark mode checkbox checked");
      localStorage[localStorageNameDarkModeStatus] = "enable";
      
      // if condition to prevent double re-load
      if(elDarkModeStylesheet.href != "popup_dark.css") {
        elDarkModeStylesheet.href="popup_dark.css";
      }
    } else {
      // disable dark mode
      console.log("dark mode checkbox not checked");
      localStorage[localStorageNameDarkModeStatus] = "disable";
      elDarkModeStylesheet.href="";
    }
  });
}
window.onload = loaded;